import os
import cv2
import torch
import numpy as np
import argparse
from ultralytics import YOLO

class KalmanFilter:
    def __init__(self):
        self.kf = cv2.KalmanFilter(4, 2)
        self.kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        self.kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.01
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1

    def update(self, x, y):
        measurement = np.array([[x], [y]], dtype=np.float32)
        self.kf.correct(measurement)
        predicted = self.kf.predict()
        return predicted[0][0], predicted[1][0]

def load_marker_map(map_path='map.txt'):
    marker_map = {}
    with open(map_path, 'r') as file:
        for line in file:
            if line.startswith('#'): continue
            parts = line.strip().split()
            if len(parts) == 8:
                marker_id = int(parts[0])
                marker_map[marker_id] = {'length': float(parts[1]), 'x': float(parts[2]), 'y': float(parts[3]), 'z': float(parts[4]), 'rot_z': float(parts[5]), 'rot_y': float(parts[6]), 'rot_x': float(parts[7])}
    return marker_map

def init_aruco_detector():
    return cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250), cv2.aruco.DetectorParameters())

def detect_aruco_markers(frame, detector):
    corners, ids, _ = detector.detectMarkers(frame)
    return corners, ids

def transform_coordinates(object_center, marker_corners, marker_info):
    marker_center = np.mean(marker_corners, axis=1).flatten()
    dx, dy = object_center[0] - marker_center[0], object_center[1] - marker_center[1]
    scale = marker_info['length'] / np.linalg.norm(marker_corners[0][0] - marker_corners[0][1])
    return marker_info['x'] + dx * scale, marker_info['y'] + dy * scale

def load_model(model_path='model.pt', device='cpu'):
    return YOLO(model_path).to(device)

def get_colors(num_classes):
    np.random.seed(42)
    return np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)

def smooth_mask(mask):
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask.astype(np.uint8) * 255, cv2.MORPH_CLOSE, kernel)
    return cv2.GaussianBlur(mask, (5, 5), 0) > 128

def draw_contours(image, mask, color, class_name, object_coords):
    mask_smoothed = smooth_mask(mask)
    contours, _ = cv2.findContours(mask_smoothed.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        if len(contour) < 5: continue
        cv2.drawContours(image, [contour], -1, color.tolist(), 3)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.putText(image, f"{class_name} ({object_coords[0]:.2f}, {object_coords[1]:.2f})", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color.tolist(), 2)
        
def merge_line_contours(mask):
    """
    Объединяет все контуры линий (LINE) в один объект.
    """
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    # Объединяем все контуры в один
    merged_contour = np.vstack(contours)
    return merged_contour
    
def is_occupied(mask, marker_corners, expand_pixels=50):
    """
    Проверяет, занято ли место в области метки с учетом площади.
    :param mask: Маска объектов YOLO.
    :param marker_corners: Углы ArUco метки.
    :param expand_pixels: На сколько пикселей расширить область метки для проверки.
    :return: True, если место занято, False иначе.
    """
    marker_corners = marker_corners[0].astype(np.int32)
    x_min, y_min = np.min(marker_corners, axis=0)
    x_max, y_max = np.max(marker_corners, axis=0)

    # Расширение области анализа
    x_min = max(0, x_min - expand_pixels)
    y_min = max(0, y_min - expand_pixels)
    x_max = min(mask.shape[1], x_max + expand_pixels)
    y_max = min(mask.shape[0], y_max + expand_pixels)

    # Выделение ROI (Region of Interest)
    roi = mask[y_min:y_max, x_min:x_max]

    # Подсчет пикселей, которые принадлежат объектам, кроме LINE и ArUco меток
    total_pixels = roi.size
    object_pixels = np.count_nonzero(roi)

    # Определяем, сколько пикселей должно быть свободно (учитывая линии и ArUco)
    threshold = total_pixels * 0.3  # Если более 30% площади занято, считаем место занятым
    return object_pixels > threshold



def check_parking_spot(frame, corners, ids, occupied_markers):
    """
    Проверяет, свободны ли парковочные места и рисует их статус.
    """
    for i, marker_id in enumerate(ids):
        if marker_id[0] in [145, 146, 144]:
            corners_i = corners[i][0].astype(int)
            x_min, y_min = np.min(corners_i, axis=0)
            x_max, y_max = np.max(corners_i, axis=0)

            # Рисуем прямоугольник вокруг метки
            if marker_id[0] in occupied_markers:
                color = (0, 0, 255)  # Красный: занято
                text = f"Occupied: {marker_id[0]}"
            else:
                color = (0, 255, 0)  # Зеленый: свободно
                text = f"Free: {marker_id[0]}"

            cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), color, 2)
            cv2.putText(frame, text, (x_min, y_min - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    return frame

def process_frame(frame, model, mode, marker_map, detector, kalman_filters):
    class_names, colors = model.names, get_colors(len(model.names))
    corners, ids = detect_aruco_markers(frame, detector)
    occupied_markers = set()
    results = model(frame)[0]

    if ids is not None:
        for i, marker_id in enumerate(ids):
            if marker_id[0] in marker_map:
                cv2.aruco.drawDetectedMarkers(frame, [corners[i]], np.array([[marker_id[0]]]))
                marker_corners = corners[i]
                if mode == "segmentation" and results.masks is not None:
                    for mask, cls in zip(results.masks.data.cpu().numpy(), results.boxes.cls.cpu().numpy()):
                        mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
                        if is_occupied(mask, marker_corners, expand_pixels=50):  # Расширяем область для проверки
                            occupied_markers.add(marker_id[0])

        # Проверяем и рисуем статус парковочных мест
        frame = check_parking_spot(frame, corners, ids, occupied_markers)

    if mode == "segmentation" and results.masks is not None:
        for mask, cls in zip(results.masks.data.cpu().numpy(), results.boxes.cls.cpu().numpy()):
            mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
            class_name, color = class_names[int(cls)], colors[int(cls) % len(colors)]
            if ids is not None:
                object_center = np.mean(np.where(mask), axis=1)[::-1]
                object_coords_list = [transform_coordinates(object_center, corners[i], marker_map[marker_id[0]]) for i, marker_id in enumerate(ids) if marker_id[0] in marker_map]
                if object_coords_list:
                    object_coords_avg = np.mean(object_coords_list, axis=0)
                    if class_name not in kalman_filters: kalman_filters[class_name] = KalmanFilter()
                    x_smooth, y_smooth = kalman_filters[class_name].update(*object_coords_avg)
                    draw_contours(frame, mask, color, class_name, (x_smooth, y_smooth))

    return frame


def main():
    parser = argparse.ArgumentParser(description="Обработка изображений и видео с YOLO и ArUco.")
    parser.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"], help="Устройство для обработки (cpu/gpu).")
    parser.add_argument("--model", type=str, default="model.pt", help="Путь к модели YOLO.")
    parser.add_argument("--input", type=str, required=True, help="Путь к изображению или видео.")
    parser.add_argument("--mode", type=str, default="segmentation", choices=["segmentation", "detection"], help="Режим работы.")
    parser.add_argument("--skip_frames", type=int, default=1, help="Количество пропускаемых кадров.")
    parser.add_argument("--speed", type=float, default=1.0, help="Скорость воспроизведения видео.")
    args = parser.parse_args()

    if not os.path.exists(args.input) and not args.input.startswith("http"):
        print(f"Ошибка: Файл '{args.input}' не найден.")
        return

    device = "cuda" if args.device == "cuda" and torch.cuda.is_available() else "cpu"
    model = load_model(args.model, device)
    marker_map, detector = load_marker_map(), init_aruco_detector()
    kalman_filters = {}

    if args.input.endswith(('.jpg', '.png', '.jpeg')):
        frame = cv2.imread(args.input)
        if frame is None: print(f"Ошибка: Не удалось открыть изображение '{args.input}'."); return
        cv2.imshow("Image", process_frame(frame, model, args.mode, marker_map, detector, kalman_filters))
        cv2.waitKey(0)
    elif args.input.endswith(('.mp4', '.avi')) or args.input.startswith("http"):
        cap = cv2.VideoCapture(args.input)
        if not cap.isOpened(): print(f"Ошибка: Не удалось открыть видео '{args.input}'."); return
        delay = int(1000 / (cap.get(cv2.CAP_PROP_FPS) * args.speed))
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break
            cv2.imshow("Video", process_frame(frame, model, args.mode, marker_map, detector, kalman_filters))
            if cv2.waitKey(delay) & 0xFF == ord('q'): break
        cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()

