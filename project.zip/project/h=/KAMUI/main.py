import os
import cv2
import torch
import numpy as np
from collections import deque
from ultralytics import YOLO

# Глобальная переменная для точки отсчета
zero_point = None  

def set_zero_point(event, x, y, flags, param):
    """ Фиксирует точку (X0, Y0) при клике мыши. """
    global zero_point
    if event == cv2.EVENT_LBUTTONDOWN:
        zero_point = (x, y)
        print(f"Нулевая точка установлена: ({x}, {y})")

def load_model(model_path='model.pt', device='cpu'):
    return YOLO(model_path).to(device)

def get_colors(num_classes):
    np.random.seed(42)
    return np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)

def smooth_mask(mask):
    """ Сглаживание границ сегментации """
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask.astype(np.uint8) * 255, cv2.MORPH_CLOSE, kernel)
    return cv2.GaussianBlur(mask, (5, 5), 0) > 128  # Бинаризация после сглаживания

def smooth_contours(mask):
    """ Сглаживание контуров маски """
    # Применяем размытие для сглаживания краев
    mask_smoothed = cv2.GaussianBlur(mask.astype(np.uint8) * 255, (5, 5), 0)
    # Бинаризация после размытия
    _, mask_smoothed = cv2.threshold(mask_smoothed, 128, 255, cv2.THRESH_BINARY)
    return mask_smoothed

def draw_bbox(image, mask, color, class_name):
    """ Вычисление и отрисовка бокса вокруг сегмента с координатами и сглаженным контуром """
    # Сглаживаем маску перед поиском контуров
    mask_smoothed = smooth_contours(mask)
    contours, _ = cv2.findContours(mask_smoothed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    for contour in contours:
        if len(contour) < 5:  # Фильтрация мелких объектов
            continue
        x, y, w, h = cv2.boundingRect(contour)
        cx, cy = x + w // 2, y + h // 2

        # Коррекция относительно нулевой точки
        x_rel, y_rel = (x - zero_point[0], y - zero_point[1]) if zero_point else (x, y)
        cx_rel, cy_rel = (cx - zero_point[0], cy - zero_point[1]) if zero_point else (cx, cy)

        # Отрисовка контура
        cv2.drawContours(image, [contour], -1, color.tolist(), 2)

        # Отрисовка прямоугольника
        cv2.rectangle(image, (x, y), (x + w, y + h), color.tolist(), 2)
        cv2.circle(image, (cx, cy), 5, color.tolist(), -1)
        text = f"{class_name} W:{w} H:{h} ({cx_rel},{cy_rel})"
        cv2.putText(image, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color.tolist(), 2)

def process_video(video_path, model, skip_frames, mode, history_size=5):
    global zero_point
    cap = cv2.VideoCapture(video_path, cv2.CAP_FFMPEG) if video_path.startswith("http") else cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Ошибка: Не удалось открыть видео '{video_path}'.")
        return
    
    frame_count = 0
    detection_history = deque(maxlen=history_size)

    class_names = model.names  
    colors = get_colors(len(class_names))

    cv2.namedWindow("Video")
    cv2.setMouseCallback("Video", set_zero_point)  # Устанавливаем обработчик кликов

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        if frame_count % skip_frames != 0:
            frame_count += 1
            continue
        
        results = model(frame)[0]
        detections = []

        if mode == "segmentation":
            masks = results.masks.data.cpu().numpy() if results.masks is not None else []
            classes = results.boxes.cls.cpu().numpy() if results.boxes is not None else []

            for mask, cls in zip(masks, classes):
                mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
                mask = smooth_mask(mask)
                class_name = class_names[int(cls)]
                color = colors[int(cls) % len(colors)]
                overlay = frame.copy()
                overlay[mask] = color
                frame = cv2.addWeighted(overlay, 0.5, frame, 0.5, 0)
                draw_bbox(frame, mask, color, class_name)
                detections.append((mask, class_name, color))

        elif mode == "detection":
            boxes = results.boxes.xyxy.cpu().numpy() if results.boxes is not None else []
            classes = results.boxes.cls.cpu().numpy() if results.boxes is not None else []

            for box, cls in zip(boxes, classes):
                x1, y1, x2, y2 = map(int, box)
                cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                # Коррекция координат относительно нулевой точки
                x1_rel, y1_rel = (x1 - zero_point[0], y1 - zero_point[1]) if zero_point else (x1, y1)
                cx_rel, cy_rel = (cx - zero_point[0], cy - zero_point[1]) if zero_point else (cx, cy)

                class_name = class_names[int(cls)]
                color = colors[int(cls) % len(colors)]
                cv2.rectangle(frame, (x1, y1), (x2, y2), color.tolist(), 2)
                text = f"{class_name} ({cx_rel},{cy_rel})"
                cv2.putText(frame, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color.tolist(), 2)
                detections.append((box, class_name, color))

        detection_history.append(detections)

        cv2.imshow("Video", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        frame_count += 1
    
    cap.release()
    cv2.destroyAllWindows()

def main():
    device = input("Выберите устройство для обработки (cpu/gpu): ").strip().lower()
    if device == "gpu":
        device = "cuda" if torch.cuda.is_available() else "cpu"
        if device == "cpu":
            print("GPU недоступен, будет использоваться CPU.")
    elif device not in ["cpu", "cuda"]:
        print("Некорректный выбор, будет использоваться CPU.")
        device = "cpu"
    
    model_path = input("Введите путь к модели (по умолчанию model.pt): ").strip() or "model.pt"
    model = load_model(model_path, device=device)

    path = input("Введите путь к видео или ссылку на видео: ").strip()
    
    mode = input("Выберите режим работы (segmentation/detection): ").strip().lower()
    if mode not in ["segmentation", "detection"]:
        print("Некорректный режим, будет использован 'segmentation'.")
        mode = "segmentation"

    skip_frames = 1
    if path.endswith(('.mp4', '.avi')) or path.startswith("http"):
        try:
            skip_frames = int(input("Сколько кадров пропускать (1 - без пропуска): ").strip())
            if skip_frames < 1:
                skip_frames = 1
        except ValueError:
            print("Некорректное значение, будет использоваться 1.")
    
    if path.startswith("http") or os.path.isfile(path):
        process_video(path, model, skip_frames, mode)
    else:
        print("Указанный путь не существует или не является файлом.")

if __name__ == "__main__":
    main()

