import os
import cv2
import torch
import numpy as np
from collections import deque
from ultralytics import YOLO

# Фильтр Калмана для сглаживания координат
class KalmanFilter:
    def __init__(self):
        self.kf = cv2.KalmanFilter(4, 2)  # 4 состояния (x, y, dx, dy), 2 измерения (x, y)
        self.kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        self.kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.01
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1

    def update(self, x, y):
        measurement = np.array([[x], [y]], dtype=np.float32)
        self.kf.correct(measurement)
        predicted = self.kf.predict()
        return predicted[0][0], predicted[1][0]

# Загрузка карты маркеров
def load_marker_map(map_path='map.txt'):
    marker_map = {}
    with open(map_path, 'r') as file:
        for line in file:
            if line.startswith('#'):  # Пропускаем комментарии
                continue
            parts = line.strip().split()
            if len(parts) == 8:
                marker_id = int(parts[0])
                length = float(parts[1])
                x, y, z = float(parts[2]), float(parts[3]), float(parts[4])
                rot_z, rot_y, rot_x = float(parts[5]), float(parts[6]), float(parts[7])
                marker_map[marker_id] = {'length': length, 'x': x, 'y': y, 'z': z, 'rot_z': rot_z, 'rot_y': rot_y, 'rot_x': rot_x}
    return marker_map

# Инициализация детектора ArUco
def init_aruco_detector():
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
    aruco_params = cv2.aruco.DetectorParameters()
    detector = cv2.aruco.ArucoDetector(aruco_dict, aruco_params)
    return detector

# Поиск ArUco-меток на кадре
def detect_aruco_markers(frame, detector):
    corners, ids, _ = detector.detectMarkers(frame)
    return corners, ids

# Преобразование координат объекта относительно ArUco-меток
def transform_coordinates(object_center, marker_corners, marker_info):
    marker_center = np.mean(marker_corners, axis=1).flatten()
    dx = object_center[0] - marker_center[0]
    dy = object_center[1] - marker_center[1]
    scale = marker_info['length'] / np.linalg.norm(marker_corners[0][0] - marker_corners[0][1])
    x = marker_info['x'] + dx * scale
    y = marker_info['y'] + dy * scale
    return x, y

# Загрузка модели YOLO
def load_model(model_path='model.pt', device='cpu'):
    return YOLO(model_path).to(device)

# Получение цветов для классов
def get_colors(num_classes):
    np.random.seed(42)
    return np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)

# Сглаживание маски
def smooth_mask(mask):
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask.astype(np.uint8) * 255, cv2.MORPH_CLOSE, kernel)
    return cv2.GaussianBlur(mask, (5, 5), 0) > 128

# Отрисовка bounding box и координат
def draw_bbox(image, mask, color, class_name, object_coords):
    mask_smoothed = smooth_mask(mask)
    mask_smoothed = mask_smoothed.astype(np.uint8) * 255
    contours, _ = cv2.findContours(mask_smoothed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        if len(contour) < 5:
            continue
        x, y, w, h = cv2.boundingRect(contour)
        cx, cy = x + w // 2, y + h // 2
        cv2.drawContours(image, [contour], -1, color.tolist(), 2)
        cv2.rectangle(image, (x, y), (x + w, y + h), color.tolist(), 2)
        cv2.circle(image, (cx, cy), 5, color.tolist(), -1)
        text = f"{class_name} ({object_coords[0]:.2f}, {object_coords[1]:.2f})"
        cv2.putText(image, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color.tolist(), 2)

# Обработка изображения
def process_image(image_path, model, mode, marker_map, detector):
    frame = cv2.imread(image_path)
    if frame is None:
        print(f"Ошибка: Не удалось открыть изображение '{image_path}'.")
        return

    class_names = model.names
    colors = get_colors(len(class_names))

    # Инициализация фильтра Калмана для каждого объекта
    kalman_filters = {}

    # Детекция ArUco-меток
    corners, ids = detect_aruco_markers(frame, detector)
    if ids is not None:
        for i, marker_id in enumerate(ids):
            marker_id = marker_id[0]
            if marker_id in marker_map:
                marker_info = marker_map[marker_id]
                marker_corners = corners[i]
                if marker_corners.shape == (1, 4, 2):
                    cv2.aruco.drawDetectedMarkers(frame, [marker_corners], np.array([[marker_id]]))

    # Детекция объектов YOLO
    results = model(frame)[0]
    detections = []

    if mode == "segmentation":
        masks = results.masks.data.cpu().numpy() if results.masks is not None else []
        classes = results.boxes.cls.cpu().numpy() if results.boxes is not None else []

        for mask, cls in zip(masks, classes):
            mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
            mask = smooth_mask(mask)
            class_name = class_names[int(cls)]
            color = colors[int(cls) % len(colors)]
            overlay = frame.copy()
            overlay[mask] = color
            frame = cv2.addWeighted(overlay, 0.5, frame, 0.5, 0)

            # Вычисление координат объекта относительно метки
            if ids is not None and len(ids) > 0:
                object_center = np.mean(np.where(mask), axis=1)[::-1]  # Центр масс объекта
                for i, marker_id in enumerate(ids):
                    marker_id = marker_id[0]
                    if marker_id in marker_map:
                        marker_info = marker_map[marker_id]
                        marker_corners = corners[i]
                        object_coords = transform_coordinates(object_center, marker_corners, marker_info)

                        # Применение фильтра Калмана
                        if class_name not in kalman_filters:
                            kalman_filters[class_name] = KalmanFilter()
                        x_smooth, y_smooth = kalman_filters[class_name].update(*object_coords)
                        object_coords = (x_smooth, y_smooth)

                        draw_bbox(frame, mask, color, class_name, object_coords)
                        detections.append((mask, class_name, color, object_coords))

    cv2.imshow("Image", frame)
    cv2.waitKey(0)  # Ожидание нажатия клавиши
    cv2.destroyAllWindows()

# Обработка видео
def process_video(video_path, model, skip_frames, mode, marker_map, detector):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Ошибка: Не удалось открыть видео '{video_path}'.")
        return

    class_names = model.names
    colors = get_colors(len(class_names))

    # Инициализация фильтра Калмана для каждого объекта
    kalman_filters = {}

    frame_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1
        if frame_count % skip_frames != 0:
            continue

        # Детекция ArUco-меток
        corners, ids = detect_aruco_markers(frame, detector)
        if ids is not None:
            for i, marker_id in enumerate(ids):
                marker_id = marker_id[0]
                if marker_id in marker_map:
                    marker_info = marker_map[marker_id]
                    marker_corners = corners[i]
                    if marker_corners.shape == (1, 4, 2):
                        cv2.aruco.drawDetectedMarkers(frame, [marker_corners], np.array([[marker_id]]))

        # Детекция объектов YOLO
        results = model(frame)[0]
        detections = []

        if mode == "segmentation":
            masks = results.masks.data.cpu().numpy() if results.masks is not None else []
            classes = results.boxes.cls.cpu().numpy() if results.boxes is not None else []

            for mask, cls in zip(masks, classes):
                mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
                mask = smooth_mask(mask)
                class_name = class_names[int(cls)]
                color = colors[int(cls) % len(colors)]
                overlay = frame.copy()
                overlay[mask] = color
                frame = cv2.addWeighted(overlay, 0.5, frame, 0.5, 0)

                # Вычисление координат объекта относительно метки
                if ids is not None and len(ids) > 0:
                    object_center = np.mean(np.where(mask), axis=1)[::-1]  # Центр масс объекта
                    for i, marker_id in enumerate(ids):
                        marker_id = marker_id[0]
                        if marker_id in marker_map:
                            marker_info = marker_map[marker_id]
                            marker_corners = corners[i]
                            object_coords = transform_coordinates(object_center, marker_corners, marker_info)

                            # Применение фильтра Калмана
                            if class_name not in kalman_filters:
                                kalman_filters[class_name] = KalmanFilter()
                            x_smooth, y_smooth = kalman_filters[class_name].update(*object_coords)
                            object_coords = (x_smooth, y_smooth)

                            draw_bbox(frame, mask, color, class_name, object_coords)
                            detections.append((mask, class_name, color, object_coords))

        cv2.imshow("Video", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Основная функция
def main():
    device = input("Выберите устройство для обработки (cpu/gpu): ").strip().lower()
    if device == "gpu":
        device = "cuda" if torch.cuda.is_available() else "cpu"
        if device == "cpu":
            print("GPU недоступен, будет использоваться CPU.")
    elif device not in ["cpu", "cuda"]:
        print("Некорректный выбор, будет использоваться CPU.")
        device = "cpu"

    model_path = input("Введите путь к модели (по умолчанию model.pt): ").strip() or "model.pt"
    if not os.path.exists(model_path):
        print(f"Ошибка: Файл модели '{model_path}' не найден.")
        return

    model = load_model(model_path, device=device)

    path = input("Введите путь к изображению или видео: ").strip()
    if not os.path.exists(path) and not path.startswith("http"):
        print(f"Ошибка: Файл '{path}' не найден.")
        return

    mode = input("Выберите режим работы (segmentation/detection): ").strip().lower()
    if mode not in ["segmentation", "detection"]:
        print("Некорректный режим, будет использован 'segmentation'.")
        mode = "segmentation"

    # Загрузка карты маркеров
    marker_map = load_marker_map('map.txt')
    detector = init_aruco_detector()

    if path.endswith(('.jpg', '.png', '.jpeg')):  # Обработка изображения
        process_image(path, model, mode, marker_map, detector)
    elif path.endswith(('.mp4', '.avi')) or path.startswith("http"):  # Обработка видео
        skip_frames = 1
        try:
            skip_frames = int(input("Сколько кадров пропускать (1 - без пропуска): ").strip())
            if skip_frames < 1:
                skip_frames = 1
        except ValueError:
            print("Некорректное значение, будет использоваться 1.")
        process_video(path, model, skip_frames, mode, marker_map, detector)
    else:
        print("Указанный путь не существует или не поддерживается.")

if __name__ == "__main__":
    main()
