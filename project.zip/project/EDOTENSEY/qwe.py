from ultralytics import YOLO

# Загрузить модель
model = YOLO('model.pt')  # предобученная модель YOLOv8n, указать название вашей модели

# Выполнить пакетное распознавание для списка изображений
results = model(['14.png'])  # возвращает список объектов Results

# Обработка списка результатов
for result in results:
    boxes = result.boxes  # объект Boxes для вывода ограничивающих рамок
    masks = result.masks  # объект Masks для вывода масок сегментации
    keypoints = result.keypoints  # объект Keypoints для вывода ключевых точек
    probs = result.probs  # объект Probs для вывода результатов классификации
    obb = result.obb  # объект Oriented boxes для вывода ориентированных рамок
    result.show()  # показать на экране
    result.save(filename='result.jpg')  # сохранить на диск изображение с результатом обработки

