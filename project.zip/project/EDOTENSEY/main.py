import os
import cv2
import torch
import numpy as np
import argparse
import logging
from ultralytics import YOLO

# Настройка логирования
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class KalmanFilter:
    def __init__(self):
        self.kf = cv2.KalmanFilter(4, 2)
        self.kf.measurementMatrix = np.array([[1, 0, 0, 0],
                                              [0, 1, 0, 0]], np.float32)
        self.kf.transitionMatrix = np.array([[1, 0, 1, 0],
                                             [0, 1, 0, 1],
                                             [0, 0, 1, 0],
                                             [0, 0, 0, 1]], np.float32)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.01
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1

    def update(self, x: float, y: float) -> tuple[float, float]:
        measurement = np.array([[x], [y]], dtype=np.float32)
        self.kf.correct(measurement)
        predicted = self.kf.predict()
        return float(predicted[0]), float(predicted[1])


def load_marker_map(map_path: str = 'map.txt') -> dict:
    marker_map = {}
    if not os.path.exists(map_path):
        logging.error(f"Файл карты маркеров '{map_path}' не найден.")
        return marker_map

    try:
        with open(map_path, 'r') as file:
            for line in file:
                if line.startswith('#'):
                    continue
                parts = line.strip().split()
                if len(parts) == 8:
                    marker_id = int(parts[0])
                    marker_map[marker_id] = {
                        'length': float(parts[1]),
                        'x': float(parts[2]),
                        'y': float(parts[3]),
                        'z': float(parts[4]),
                        'rot_z': float(parts[5]),
                        'rot_y': float(parts[6]),
                        'rot_x': float(parts[7])
                    }
    except Exception as e:
        logging.error(f"Ошибка при загрузке карты маркеров: {e}")
    return marker_map


def init_aruco_detector():
    """
    Инициализирует детектор ArUco‑меток.
    """
    if hasattr(cv2.aruco, 'ArucoDetector'):
        dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
        parameters = cv2.aruco.DetectorParameters()
        detector = cv2.aruco.ArucoDetector(dictionary, parameters)
    else:
        dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_250)
        parameters = cv2.aruco.DetectorParameters_create()
        detector = cv2.aruco.Detector(dictionary, parameters)
    return detector


def detect_aruco_markers(frame: np.ndarray, detector) -> tuple:
    """
    Обнаруживает ArUco‑метки на кадре.
    :return: (corners, ids) обнаруженных меток.
    """
    corners, ids, _ = detector.detectMarkers(frame)
    return corners, ids


def merge_line_contours(mask: np.ndarray) -> np.ndarray:
    """
    Объединяет все контуры из маски класса LINE в один.
    """
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    merged_contour = np.vstack(contours) if len(contours) > 1 else contours[0]
    return merged_contour


def transform_coordinates(object_center: np.ndarray, marker_corners: np.ndarray, marker_info: dict) -> tuple:
    """
    Преобразует координаты центра объекта из пиксельных координат в "мировые" с повышенной точностью.
    Вычисления проводятся с использованием double precision (np.float64).
    """
    marker_center = np.mean(marker_corners, axis=1).flatten().astype(np.float64)
    dx = float(object_center[0]) - float(marker_center[0])
    dy = float(object_center[1]) - float(marker_center[1])
    pixel_distance = np.linalg.norm(marker_corners[0][0].astype(np.float64) - marker_corners[0][1].astype(np.float64))
    scale = marker_info['length'] / pixel_distance if pixel_distance != 0 else 1.0
    world_x = marker_info['x'] + dx * scale
    world_y = marker_info['y'] + dy * scale
    return world_x, world_y


def get_colors(num_classes: int) -> np.ndarray:
    """
    Генерирует фиксированный набор цветов для классов.
    """
    np.random.seed(42)
    return np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)


def process_frame(frame: np.ndarray, model, mode: str, marker_map: dict, detector, kalman_filters: dict) -> np.ndarray:
    """
    Обрабатывает один кадр:
      - Выполняется инференс модели YOLO (сегментация).
      - Для каждого обнаруженного объекта отрисовывается контур его маски.
      - Если обнаружено ≥2 объекта LINE, они объединяются в полигон, по которому определяется состояние парковочного места.
      - Если объектов LINE недостаточно, fallback‑логика по ArUco‑меткам проверяет занятость.
      - Отображаются ArUco‑метки с использованием полилиний и выводом ID.
    """
    class_names = model.names
    colors = get_colors(len(class_names))
    
    # Обнаружение ArUco‑меток (используется для fallback и отображения)
    corners, ids = detect_aruco_markers(frame, detector)
    
    # Списки для хранения обнаруженных объектов
    line_contours = []   # для объектов класса LINE (маски)
    other_objects = []   # для остальных объектов (храним: (центр, class_name, цвет))
    
    # Выполнение инференса модели
    results = model(frame)[0]
    
    if mode == "segmentation" and results.masks is not None:
        for mask, cls in zip(results.masks.data.cpu().numpy(), results.boxes.cls.cpu().numpy()):
            # Маска приводится к размеру кадра
            mask_resized = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST) > 0.5
            class_idx = int(cls)
            class_name = class_names[class_idx]
            color = tuple(int(c) for c in colors[class_idx % len(colors)].tolist())
            
            # Отрисовка контура для каждого объекта
            mask_uint8 = (mask_resized.astype(np.uint8)) * 255
            contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                cv2.drawContours(frame, contours, -1, color, 2)
                M = cv2.moments(contours[0])
                if M["m00"] != 0:
                    cX = int(M["m10"] / M["m00"])
                    cY = int(M["m01"] / M["m00"])
                    cv2.putText(frame, class_name, (cX, cY), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            
            # Сохранение данных для определения занятости парковочного места
            if class_name.upper() == "LINE":
                merged_contour = merge_line_contours(mask_resized)
                if merged_contour is not None:
                    line_contours.append(merged_contour)
            else:
                ys, xs = np.where(mask_resized)
                if len(xs) == 0 or len(ys) == 0:
                    continue
                center = (float(np.mean(xs)), float(np.mean(ys)))
                other_objects.append((center, class_name, color))
    
    # 1. Если обнаружено ≥2 объекта LINE – определяем состояние парковочного места по разметке (tape)
    if len(line_contours) >= 2:
        merged_lines = np.vstack(line_contours)
        hull = cv2.convexHull(merged_lines)
        occupied = False
        for (center, obj_class, obj_color) in other_objects:
            if cv2.pointPolygonTest(hull, center, False) >= 0:
                occupied = True
                break
        if occupied:
            text = "Occupied Parking Spot (Tape)"
            draw_color = (0, 0, 255)
        else:
            text = "Free Parking Spot (Tape)"
            draw_color = (0, 255, 0)
        cv2.drawContours(frame, [hull], -1, draw_color, 3)
        M = cv2.moments(hull)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
        else:
            cX, cY = 0, 0
        cv2.putText(frame, text, (cX, cY), cv2.FONT_HERSHEY_SIMPLEX, 0.8, draw_color, 2)
    
    # 2. Если объектов LINE недостаточно – fallback по ArUco‑меткам с проверкой занятости
    elif ids is not None and len(ids) > 0:
        for i, marker_id in enumerate(ids):
            marker_id_val = marker_id[0]
            if marker_id_val in marker_map:
                marker_info = marker_map[marker_id_val]
                marker_world_x = marker_info['x']
                marker_world_y = marker_info['y']
                occupied = False
                marker_corners_original = corners[i]
                for (center, obj_class, obj_color) in other_objects:
                    world_coords = transform_coordinates(np.array(center), marker_corners_original, marker_info)
                    if abs(world_coords[0] - marker_world_x) < 0.5 and abs(world_coords[1] - marker_world_y) < 0.5:
                        occupied = True
                        break
                marker_corners_draw = marker_corners_original.reshape((4, 2)).astype(int)
                cv2.polylines(frame, [marker_corners_draw], True, (255, 0, 0), 2)
                x_min, y_min = np.min(marker_corners_draw, axis=0)
                if occupied:
                    draw_color = (0, 0, 255)
                    occ_text = f"Occupied Spot (Marker {marker_id_val})"
                else:
                    draw_color = (0, 255, 0)
                    occ_text = f"Free Spot (Marker {marker_id_val})"
                cv2.putText(frame, occ_text, (x_min, y_min - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, draw_color, 2)
                cv2.putText(frame, f"ID: {marker_id_val}", tuple(marker_corners_draw[0]),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
    else:
        cv2.putText(frame, "No parking spot info", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)
    
    return frame


def load_model(model_path: str = 'model.pt', device: str = 'cpu'):
    """
    Загружает YOLO‑модель с указанного пути.
    """
    if not os.path.exists(model_path):
        logging.error(f"Файл модели '{model_path}' не найден.")
        raise FileNotFoundError(f"Файл модели '{model_path}' не найден.")
    model = YOLO(model_path)
    return model.to(device)


def main():
    parser = argparse.ArgumentParser(description="Обработка изображений и видео с YOLO и ArUco.")
    parser.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"],
                        help="Устройство для обработки (cpu/gpu).")
    parser.add_argument("--model", type=str, default="model.pt", help="Путь к модели YOLO.")
    parser.add_argument("--input", type=str, required=True, help="Путь к изображению или видео.")
    parser.add_argument("--mode", type=str, default="segmentation",
                        choices=["segmentation", "detection"], help="Режим работы.")
    parser.add_argument("--skip_frames", type=int, default=1, help="Количество пропускаемых кадров.")
    parser.add_argument("--speed", type=float, default=1.0, help="Скорость воспроизведения видео.")
    args = parser.parse_args()

    if not os.path.exists(args.input) and not args.input.startswith("http"):
        logging.error(f"Ошибка: Файл '{args.input}' не найден.")
        return

    device = "cuda" if args.device == "cuda" and torch.cuda.is_available() else "cpu"
    try:
        model = load_model(args.model, device)
    except FileNotFoundError:
        return

    marker_map = load_marker_map()  # Карта маркеров используется для fallback‑логики
    detector = init_aruco_detector()
    kalman_filters = {}

    if args.input.lower().endswith(('.jpg', '.png', '.jpeg')):
        frame = cv2.imread(args.input)
        if frame is None:
            logging.error(f"Ошибка: Не удалось открыть изображение '{args.input}'.")
            return
        processed_frame = process_frame(frame, model, args.mode, marker_map, detector, kalman_filters)
        cv2.imshow("Image", processed_frame)
        cv2.waitKey(0)
    elif args.input.lower().endswith(('.mp4', '.avi')) or args.input.startswith("http"):
        cap = cv2.VideoCapture(args.input)
        if not cap.isOpened():
            logging.error(f"Ошибка: Не удалось открыть видео '{args.input}'.")
            return
        fps = cap.get(cv2.CAP_PROP_FPS)
        delay = int(1000 / (fps * args.speed)) if fps > 0 else 30
        frame_count = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            if frame_count % args.skip_frames == 0:
                processed_frame = process_frame(frame, model, args.mode, marker_map, detector, kalman_filters)
                cv2.imshow("Video", processed_frame)
            frame_count += 1
            if cv2.waitKey(delay) & 0xFF == ord('q'):
                break
        cap.release()
    else:
        logging.error("Неподдерживаемый формат входного файла.")
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

